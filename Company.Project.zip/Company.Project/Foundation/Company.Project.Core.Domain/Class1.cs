﻿using System;

namespace Company.Project.Core.Domain
{
    public class Class1
    {
    }
}
