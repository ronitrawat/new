﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Company.Project.Core.PlugIn
{
    public interface IPlugin
    {
        string Name { get; }
    }
}
