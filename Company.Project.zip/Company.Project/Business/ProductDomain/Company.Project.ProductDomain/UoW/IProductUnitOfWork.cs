﻿using Company.Project.Core.Data.Transaction;
using System;
using System.Collections.Generic;
using System.Text;

namespace Company.Project.ProductDomain.UoW
{
    public interface IProductUnitOfWork:IUnitOfWork
    {
    }
}
